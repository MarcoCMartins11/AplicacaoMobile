package com.example.autogaiense

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.FocusFinder
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import com.example.autogaiense.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    //ViewBinding
    private lateinit var binding: ActivityLoginBinding

    //ActionBar
    private lateinit var actionBar: ActionBar

    //ProgressDialog
    private lateinit var progressDialog:ProgressDialog

    //FirebaseAuth
    private lateinit var firebaseAuth: FirebaseAuth
    private var email = ""
    private var  password = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //ActionBar configuration

        actionBar = supportActionBar!!
        actionBar.title = "Login"

        //ProgressDialog configuration
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Por favor espere")
        progressDialog.setMessage("A Executar o login...")
        progressDialog.setCanceledOnTouchOutside(false)

        //Iniciar Firebase
        firebaseAuth = FirebaseAuth.getInstance()
        checkuser()

        //Click para o registo
        binding.noAccountTv.setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }

        //Click de Login
        binding.loginBtn.setOnClickListener {
            //Validar dados antes de permitir Login
            validateData()
        }
    }

    private fun validateData() {
        // Validação dos dados
        email = binding.emailEt.text.toString().trim()
        password = binding.passwordEt.text.toString().trim()  // Acessar os dados //

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            // Formato errado do email //
            binding.emailEt.error = "Email Incorreto !!!!"
        }
        else if (TextUtils.isEmpty(password)){
            // Erro por não inserir password //
            binding.passwordEt.error = "Por favor insira a password"
        }
        else{
            // Dados validades! --> Prosseguir login //
            firebaseLogin()
        }
    }

    private fun firebaseLogin() {
        // Mostrar o progresso do login
        progressDialog.show()
        firebaseAuth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                // Sucesso no login //
                progressDialog.dismiss()
                // Dados do utilizador //
                val firebaseUser = firebaseAuth.currentUser
                val email = firebaseUser!!.email
                Toast.makeText(this, "Sessão iniciada por $email", Toast.LENGTH_SHORT).show()
                // Abrir o perfile do utilizador //
                startActivity(Intent(this, ProfileActivity::class.java))
                finish()
            }
            .addOnFailureListener { e->
                // Falha no login //
                progressDialog.dismiss()
                Toast.makeText(this, "O login falhou devido a ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }


    private fun checkuser() {
        //Se o utilizador já estiver autenticado --> profile activity

        //Current user
        val firebaseUser = firebaseAuth.currentUser
        if (firebaseUser != null)
            //Utilizador já fez login
            startActivity(Intent(this, ProfileActivity::class.java))
            finish()
    }


}