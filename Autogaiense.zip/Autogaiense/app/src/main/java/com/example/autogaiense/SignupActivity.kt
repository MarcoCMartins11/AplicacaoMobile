package com.example.autogaiense

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import com.example.autogaiense.databinding.ActivitySignupBinding
import com.google.firebase.auth.FirebaseAuth

class SignupActivity : AppCompatActivity() {
    //ViewBinding
    private lateinit var binding: ActivitySignupBinding

    //ActionBar
    private lateinit var actionBar: ActionBar

    //ProgressDialog
    private lateinit var progressDialog: ProgressDialog

    //FirebaseAuth
    private lateinit var firebaseAuth: FirebaseAuth
    private var name = ""
    private var email = ""
    private var password = ""
    private var address = ""
    private var phone = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Configurar Action Bar e Buttão de voltar //
        actionBar = supportActionBar!!
        actionBar.title = "Registo"
        actionBar.setDisplayHomeAsUpEnabled(true)
        actionBar.setDisplayShowHomeEnabled(true)

        // COnfigurar ProgressDialog //
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Por favor espere")
        progressDialog.setMessage("A criar conta...")
        progressDialog.setCanceledOnTouchOutside(false)

        //Iniciar firebase conect //
        firebaseAuth = FirebaseAuth.getInstance()

        //Click do registo //
        binding.signupBtn.setOnClickListener {
            // Validar dados para o registo
            validateData()
        }
    }

    private fun validateData() {
        // Get Dados //
        name = binding.nameEt.text.toString().trim()
        email = binding.emailEt.text.toString().trim()
        password = binding.passwordEt.text.toString().trim()
        address = binding.addressEt.text.toString().trim()
        phone = binding.phoneEt.text.toString().trim()

        // Validar os dados //
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            // Formato invalido do email
            binding.emailEt.error = "Formato do email inválido"
        }
        else if (TextUtils.isEmpty(password)){
            //password vazia //
            binding.passwordEt.error = "Por favor insira uma password"
        }
        else if (TextUtils.isEmpty(name)){
            //nome vazio //
            binding.nameEt.error = "Por favor insira um Nome"
        }
        else if (TextUtils.isEmpty(email)){
            //email vazio //
            binding.emailEt.error = "Por favor insira um email"
        }
        else if (TextUtils.isEmpty(address)){
            //morada vazia //
            binding.addressEt.error = "Por favor insira uma morada"
        }
        else if (TextUtils.isEmpty(phone)){
            //contacto vazio //
            binding.phoneEt.error = "Por favor insira um contacto válido"
        }
        else if (password.length < 5){
            //password vazia //
            binding.passwordEt.error = "A password deve ter pelo menos 5 caracteres!!"
        }
        else{
            // Dados validados // Prosseguir com o registo //
            firebaseSignup()
        }
    }

    private fun firebaseSignup() {
        // Progess Dialog //
        progressDialog.show()

        // Criar conta //
        firebaseAuth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                // Registo com sucesso //
                progressDialog.dismiss()
                // Utilizador //
                val firebaseUser = firebaseAuth.currentUser
                val email = firebaseUser!!.email
                Toast.makeText(this, "cona criada com o email $email", Toast.LENGTH_SHORT).show()

                // Reencaminhar para a página de profile
                startActivity(Intent(this, ProfileActivity::class.java))
                finish()
            }
            .addOnFailureListener {e->
                // Registo falhou //
                progressDialog.dismiss()
                Toast.makeText(this, "Registo falhou devido a ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed() // Voltar à pagina anterior
        return super.onSupportNavigateUp()
    }
}