package com.example.autogaiense

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.ActionBar
import com.example.autogaiense.databinding.ActivityProfileBinding
import com.google.firebase.auth.FirebaseAuth

class ProfileActivity : AppCompatActivity() {
    //ViewBinding
    private lateinit var binding: ActivityProfileBinding

    //ActionBar
    private lateinit var actionBar: ActionBar

    //FirebaseAuch
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configurar ActionBar //
        actionBar = supportActionBar!!
        actionBar.title = "Página Principal"

        // Iniciar Firebase auch //
        firebaseAuth = FirebaseAuth.getInstance()
        checkUser()

        // Click para Logout //
        binding.logoutBt.setOnClickListener {
            firebaseAuth.signOut()
            checkUser()
        }

    }

    private fun checkUser() {
        // Verificar utilizador //
        val firebaseUser = firebaseAuth.currentUser
        if (firebaseUser != null) {
            // Utilizador com login feito // Dados do utilizador //
            val email = firebaseUser.email
            binding.emailTv.text = email
        }
        else{
            // Utilizador sem login feito -> Redirecionar para login page
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }


}